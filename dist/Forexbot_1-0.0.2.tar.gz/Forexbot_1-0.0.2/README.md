# NNFX-BOT
This is a nnfx bot uses algorithm with a check
